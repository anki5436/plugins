<?php
/*
Plugin Name: Custom Reg
Version: 2.1
Description: Ankur Mehta Custom user registration plugin.

*/


function custom_am_form($username, $email, $first_name) {
	?>
	<form action="<?php echo $_SERVER['REQUEST_URI']; ?>" method="post">
	<p>
		<label>
			First Name<br/>
			<input type="text" class="" name="first_name" />
		</label>
	</p>
	
	<p>
		<label>
			Username<br/>
			<input type="text" class="" name="username" />
		</label>
	</p>
	<p>
		<label>
			Email<br/>
			<input type="text" class="" name="email" />
		</label>
	</p>
	<input type="submit" name="submit" value="Register"/>
	</form>
	
	<?php
$getalluser = get_users( array( 'role__in' => array( 'author', 'subscriber' ) ) );
$count = 1;
echo '<table><tr><td>Sr no.</td><td>Subscriber Names</td></tr>';
foreach ( $getalluser as $user ) {
    echo '<tr><td>'.$count.'</td><td>'. $user->display_name .'</td></tr>';
	$count++;
}
echo '</table>';
	
}


function run_am_form() {
    global $username, $email, $first_name, $last_name;
        $userdata = array(
        'user_login'    =>   $username,
        'user_email'    =>   $email,
        'first_name'    =>   $first_name,
        );
        $user = wp_insert_user( $userdata );
        echo 'Registration complete.';   
   }



function custom_am_reg_form() {
    if ( isset($_POST['submit'] ) ) {
         
        global $username, $email, $first_name, $last_name;
        $first_name =   $_POST['first_name'];
        $username   =   $_POST['username'];
        $email      =   $_POST['email'];
        
        run_am_form(
        $first_name,
        $username,
        $email
        );
    }
 
    custom_am_form(
        $first_name,
        $username,
        $email
        );
}
add_shortcode( 'custom_registration', 'custom_am_reg_form' );
	
?>